import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

import cs3500.planner.model.CentralSystem;
import cs3500.planner.model.Day;
import cs3500.planner.model.Location;
import cs3500.planner.model.NUEvent;
import cs3500.planner.model.Schedule;
import cs3500.planner.model.Time;
import cs3500.planner.model.User;
import cs3500.planner.xmlbehavior.XMLHelper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Tests for the operations in the model.
 */
public class ModelTests {
  CentralSystem planner;
  User claire;
  User cali;
  User theresa;
  Schedule claireSchedule;
  Schedule caliSchedule;
  Schedule theresaSchedule;
  XMLHelper claireHelp;
  XMLHelper caliHelp;
  XMLHelper theresaHelp;

  //TODO: ADD LOCAL FILE SUPPORT?
  @Before
  public void init() {
    claireSchedule = new Schedule("Claire Stewart", new ArrayList<>());
    caliSchedule = new Schedule("Cali Behling", new ArrayList<>());
    theresaSchedule = new Schedule("Theresa Vandis", new ArrayList<>());
    claire = new User("Claire Stewart", claireSchedule);
    cali = new User("Cali Behling", caliSchedule);
    theresa = new User("Theresa Vandis", theresaSchedule);
    claireHelp = new XMLHelper(claireSchedule);
    caliHelp = new XMLHelper(caliSchedule);
    theresaHelp = new XMLHelper(theresaSchedule);
    claireHelp.saveSchedule();
    caliHelp.saveSchedule();
    theresaHelp.saveSchedule();

    File claireXML =
            new File("Claire Stewart-schedule.xml");
    File caliXML =
            new File("Cali Behling-schedule.xml");
    File theresaXML =
            new File("Theresa Vandis-schedule.xml");
    planner = new CentralSystem(new ArrayList<>(Arrays.asList(claireXML, caliXML,
            theresaXML)));
    planner.uploadUser();
    claire = planner.usersInSystem().get(0);
    cali = planner.usersInSystem().get(1);
    theresa = planner.usersInSystem().get(2);
  }

  @Test
  public void testCreateEventNoInvitees() {
    init();
    NUEvent ood = new NUEvent("OOD", new ArrayList<>(Arrays.asList(cali)),
            new Location(true, "Churchill 101"),
            new Time(Day.TUESDAY, Day.TUESDAY, "0950", "1130"), cali);
    NUEvent meeting = new NUEvent("Meeting with boss",
            new ArrayList<>(Arrays.asList(theresa)),
            new Location(true, "MimeCast"),
            new Time(Day.THURSDAY, Day.THURSDAY, "1600", "1630"),
            theresa);
    NUEvent gym = new NUEvent("Gym Sesh", new ArrayList<>(Arrays.asList(theresa)),
            new Location(false, "SquashBusters"),
            new Time(Day.MONDAY, Day.MONDAY, "1230", "1330"), theresa);

    //Creates an event with no invitees. Only adds the event to cali's schedule
    planner.createEvent("OOD", new ArrayList<>(),
            new Location(true, "Churchill 101"),
            new Time(Day.TUESDAY, Day.TUESDAY, "0950", "1130"), cali);
    //Creates an event with no invitees. Only adds the event to theresa's schedule
    planner.createEvent("Meeting with boss", new ArrayList<>(),
            new Location(true, "MimeCast"),
            new Time(Day.THURSDAY, Day.THURSDAY, "1600", "1630"),
            theresa);
    planner.createEvent("Gym Sesh", new ArrayList<>(),
            new Location(false, "SquashBusters"),
            new Time(Day.MONDAY, Day.MONDAY, "1230", "1330"), theresa);

    //Confirms that the events have been added
    assertTrue(cali.containsEvent(ood));
    assertTrue(theresa.containsEvent(meeting));
    assertTrue(theresa.containsEvent(gym));
    assertFalse(claire.containsEvent(gym));
  }

  @Test
  public void testCreateEventWithInvitees() {
    init();
    NUEvent ood = new NUEvent("OOD", new ArrayList<>(Arrays.asList(cali)),
            new Location(true, "Churchill 101"),
            new Time(Day.TUESDAY, Day.TUESDAY, "0950", "1130"), cali);
    planner.createEvent("OOD", new ArrayList<>(),
            new Location(true, "Churchill 101"),
            new Time(Day.TUESDAY, Day.TUESDAY, "0950", "1130"), cali);
    planner.createEvent("Meeting with boss", new ArrayList<>(),
            new Location(true, "MimeCast"),
            new Time(Day.THURSDAY, Day.THURSDAY, "1600", "1630"),
            theresa);
    planner.createEvent("Gym Sesh", new ArrayList<>(),
            new Location(false, "SquashBusters"),
            new Time(Day.MONDAY, Day.MONDAY, "1230", "1330"), theresa);

    //Creates events with 2 invitees. Adds it to cali and claire's schedules, theresa has a time
    //conflict.
    planner.createEvent("Lunch", new ArrayList<>(Arrays.asList(cali, theresa)),
            new Location(false, "Tatte"),
            new Time(Day.MONDAY, Day.MONDAY, "1200", "1300"), claire);
    NUEvent lunch = new NUEvent("Lunch",
            new ArrayList<>(Arrays.asList(claire, cali, theresa)),
            new Location(false, "Tatte"),
            new Time(Day.MONDAY, Day.MONDAY, "1200", "1300"), claire);
    assertTrue(cali.containsEvent(ood));
    assertTrue(claire.containsEvent(lunch));
    assertTrue(cali.containsEvent(lunch));
    assertFalse(theresa.containsEvent(lunch));

    //Creates event with 2 invitees. Adds it to cali, claire, and theresa's schedules.
    planner.createEvent("Party", new ArrayList<>(Arrays.asList(claire, cali)),
            new Location(false, "My house"),
            new Time(Day.FRIDAY, Day.FRIDAY, "2000", "2300"), theresa);
    NUEvent party = new NUEvent("Party",
            new ArrayList<>(Arrays.asList(theresa, claire, cali)),
            new Location(false, "My house"),
            new Time(Day.FRIDAY, Day.FRIDAY, "2000", "2300"), theresa);
    assertTrue(cali.containsEvent(party));
    assertTrue(claire.containsEvent(party));
    assertTrue(theresa.containsEvent(party));
  }

  @Test
  public void testOverlappingTimes() {
    init();
    //Creates an event with 2 invitees. Adds it to cali and theresa's schedules.
    planner.createEvent("Camping", new ArrayList<User>(Arrays.asList(cali, theresa)),
            new Location(false, "The Fens"),
            new Time(Day.THURSDAY, Day.SATURDAY, "0900", "1700"), claire);
    //Creates an event with no invitees. Does not add it to cali's schedule because of a time
    //conflict.
    planner.createEvent("Dinner", new ArrayList<User>(),
            new Location(false, "Barcelona"),
            new Time(Day.FRIDAY, Day.FRIDAY, "1900", "2100"), cali);
    NUEvent camping = new NUEvent("Camping",
            new ArrayList<User>(Arrays.asList(claire, cali, theresa)),
            new Location(false, "The Fens"),
            new Time(Day.THURSDAY, Day.SATURDAY, "0900", "1700"), claire);
    NUEvent dinner = new NUEvent("Dinner", new ArrayList<User>(Arrays.asList(cali)),
            new Location(false, "Barcelona"),
            new Time(Day.FRIDAY, Day.FRIDAY, "1900", "2100"), cali);
    assertTrue(cali.containsEvent(camping));
    assertFalse(cali.containsEvent(dinner));
  }

  @Test
  public void removeEvent() {
    init();
    planner.createEvent("OOD", new ArrayList<>(),
            new Location(true, "Churchill 101"),
            new Time(Day.TUESDAY, Day.TUESDAY, "0950", "1130"), cali);
    planner.createEvent("Meeting with boss", new ArrayList<>(),
            new Location(true, "MimeCast"),
            new Time(Day.THURSDAY, Day.THURSDAY, "1600", "1630"),
            theresa);
    planner.createEvent("Gym Sesh", new ArrayList<>(),
            new Location(false, "SquashBusters"),
            new Time(Day.MONDAY, Day.MONDAY, "1230", "1330"), theresa);
    planner.createEvent("Lunch", new ArrayList<>(Arrays.asList(cali, theresa)),
            new Location(false, "Tatte"),
            new Time(Day.MONDAY, Day.MONDAY, "1200", "1300"), claire);
    NUEvent lunch = new NUEvent("Lunch",
            new ArrayList<>(Arrays.asList(claire, cali, theresa)),
            new Location(false, "Tatte"),
            new Time(Day.MONDAY, Day.MONDAY, "1200", "1300"), claire);
    NUEvent gym = new NUEvent("Gym Sesh",
            new ArrayList<>(Arrays.asList(theresa)),
            new Location(false, "SquashBusters"),
            new Time(Day.MONDAY, Day.MONDAY, "1230", "1330"), theresa);
    assertTrue(theresa.containsEvent(gym));
    theresa.removeEvent(gym, theresa);
    assertFalse(theresa.containsEvent(gym));

    assertTrue(claire.containsEvent(lunch));
    assertTrue(cali.containsEvent(lunch));
    planner.removeEvent(lunch, claire);
    assertFalse(claire.containsEvent(lunch));
    assertFalse(cali.containsEvent(lunch));
  }

  @Test
  public void testModifyEventNoInvitees() {
    init();
    //Modifies an event for one user.
    planner.createEvent("OOD", new ArrayList<>(),
            new Location(true, "Churchill 101"),
            new Time(Day.TUESDAY, Day.TUESDAY, "0950", "1130"), cali);
    NUEvent ood = new NUEvent("OOD", new ArrayList<>(Arrays.asList(cali)),
            new Location(true, "Churchill 101"),
            new Time(Day.TUESDAY, Day.TUESDAY, "0950", "1130"), cali);
    assertTrue(cali.containsEvent(ood));
    planner.modifyEvent("OOD", "Algo", null,
            new Location(true, "Richards 210"), null);
    NUEvent algo = new NUEvent("Algo", new ArrayList<>(Arrays.asList(cali)),
            new Location(true, "Richards 210"),
            new Time(Day.TUESDAY, Day.TUESDAY, "0950", "1130"), cali);
    assertTrue(cali.containsEvent(algo));
  }

  @Test
  public void testModifyEventWithInvitees() {
    //Modifies an event for all invitees.
    planner.createEvent("Lunch", new ArrayList<>(Arrays.asList(cali, theresa)),
            new Location(false, "Tatte"),
            new Time(Day.MONDAY, Day.MONDAY, "1200", "1300"), claire);
    NUEvent lunch = new NUEvent("Lunch",
            new ArrayList<>(Arrays.asList(claire, cali, theresa)),
            new Location(false, "Tatte"),
            new Time(Day.MONDAY, Day.MONDAY, "1200", "1300"), claire);
    assertTrue(claire.containsEvent(lunch));
    assertTrue(cali.containsEvent(lunch));

    planner.modifyEvent("Lunch", null, null,
            new Location(false, "Pavement"), null);
    NUEvent newLunch = new NUEvent("Lunch",
            new ArrayList<>(Arrays.asList(claire, cali, theresa)),
            new Location(false, "Pavement"),
            new Time(Day.MONDAY, Day.MONDAY, "1200", "1300"), claire);
    assertTrue(claire.containsEvent(newLunch));
    assertTrue(cali.containsEvent(newLunch));
  }

  @Test
  public void testUploadUser() {
    init();
    assertTrue(planner.usersInSystem().contains(claire));
    assertTrue(planner.usersInSystem().contains(cali));
    assertTrue(planner.usersInSystem().contains(theresa));
    planner.createEvent("Lunch", new ArrayList<>(Arrays.asList(cali, theresa)),
            new Location(false, "Tatte"),
            new Time(Day.MONDAY, Day.MONDAY, "1200", "0100"), claire);
    assertTrue(planner.usersInSystem().contains(claire));
  }

  @Test
  public void testUsersEvents() {
    init();
    planner.createEvent("Meeting with boss", new ArrayList<>(),
            new Location(true, "MimeCast"),
            new Time(Day.THURSDAY, Day.THURSDAY, "1600", "1630"),
            theresa);
    planner.createEvent("Gym Sesh", new ArrayList<>(),
            new Location(false, "SquashBusters"),
            new Time(Day.MONDAY, Day.MONDAY, "1230", "1330"), theresa);
    assertEquals(new ArrayList<NUEvent>(Arrays.asList(
            new NUEvent("Meeting with boss", new ArrayList<>(),
            new Location(true, "MimeCast"),
            new Time(Day.THURSDAY, Day.THURSDAY, "1600", "1630"),
            theresa), new NUEvent("Gym Sesh", new ArrayList<>(),
            new Location(false, "SquashBusters"),
            new Time(Day.MONDAY, Day.MONDAY, "1230", "1330"), theresa))),
            planner.usersEvents(theresa));
  }

  @Test
  public void testCheckForTimeConflicts() {
    planner.createEvent("Gym Sesh", new ArrayList<>(),
            new Location(false, "SquashBusters"),
            new Time(Day.MONDAY, Day.MONDAY, "1230", "1330"), theresa);
    NUEvent lunch = new NUEvent("Lunch", new ArrayList<>(Arrays.asList(cali, theresa)),
            new Location(false, "Tatte"),
            new Time(Day.MONDAY, Day.MONDAY, "1200", "1300"), claire);
    assertTrue(planner.checkForTimeConflict(lunch, theresa));
  }
}
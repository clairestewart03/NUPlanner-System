import org.junit.Test;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

import cs3500.planner.model.Day;
import cs3500.planner.model.Location;
import cs3500.planner.model.NUEvent;
import cs3500.planner.model.Schedule;
import cs3500.planner.model.Time;
import cs3500.planner.model.User;
import cs3500.planner.xmlbehavior.XMLHelper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Test class to test the functionality of reading and writing XML files.
 */
public class XMLHelperTests {

  @Test
  public void testWriteXML() {
    Schedule s = new Schedule("Claire", new ArrayList<>());
    User u1 = new User("Claire", s);
    User u2 = new User("Cali", new Schedule("Cali",
            new ArrayList<NUEvent>()));
    s.addEvent("Class", new ArrayList<>(Arrays.asList(u2)), new Location(false,
                    "Campus"), new Time(Day.MONDAY, Day.MONDAY, "0950", "1130"),
            u1);
    s.addEvent("Dance", new ArrayList<>(), new Location(false, "Knowles 010"),
            new Time(Day.THURSDAY, Day.THURSDAY, "1800", "2000"), u1);
    XMLHelper claireHelp = new XMLHelper(s);
    claireHelp.saveSchedule();
    assertTrue(new File("Claire-schedule.xml").exists());
  }

  @Test
  public void testReadXML() {
    XMLHelper xmlHelp = new XMLHelper();
    File xmlFile =
            new File("Claire Stewart-schedule.xml");
    File f = new File("/Users/clairestewart/Documents/test.xml");
    xmlHelp.readXML(xmlFile);
    User claire = new User("Claire Stewart", new Schedule("Claire Stewart",
            new ArrayList<>()));
    assertEquals(claire, xmlHelp.readXML(xmlFile));
  }
}
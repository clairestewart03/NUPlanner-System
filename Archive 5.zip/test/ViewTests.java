import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

import cs3500.planner.model.CentralSystem;
import cs3500.planner.model.Day;
import cs3500.planner.model.Location;
import cs3500.planner.model.NUEvent;
import cs3500.planner.model.Schedule;
import cs3500.planner.model.Time;
import cs3500.planner.model.User;
import cs3500.planner.xmlbehavior.XMLHelper;
import cs3500.planner.view.NUPlannerTextView;
import cs3500.planner.view.NUPlannerView;

import static org.junit.Assert.assertEquals;

/**
 * Class representing tests for the NUPlannerView.
 */
public class ViewTests {

  CentralSystem planner;
  User claire;
  User cali;
  User theresa;
  Schedule claireSchedule;
  Schedule caliSchedule;
  Schedule theresaSchedule;
  XMLHelper claireHelp;
  XMLHelper caliHelp;
  XMLHelper theresaHelp;

  @Before
  public void init() {
    claireSchedule = new Schedule("Claire Stewart", new ArrayList<>());
    caliSchedule = new Schedule("Cali Behling", new ArrayList<>());
    theresaSchedule = new Schedule("Theresa Vandis", new ArrayList<>());
    claire = new User("Claire Stewart", claireSchedule);
    cali = new User("Cali Behling", caliSchedule);
    theresa = new User("Theresa Vandis", theresaSchedule);
    claireHelp = new XMLHelper(claireSchedule);
    caliHelp = new XMLHelper(caliSchedule);
    theresaHelp = new XMLHelper(theresaSchedule);
    claireHelp.saveSchedule();
    caliHelp.saveSchedule();
    theresaHelp.saveSchedule();
    File claireXML =
            new File("Claire Stewart-schedule.xml");
    File caliXML =
            new File("Cali Behling-schedule.xml");
    File theresaXML =
            new File("Theresa Vandis-schedule.xml");
    planner = new CentralSystem(new ArrayList<File>(Arrays.asList(claireXML, caliXML)));
    planner.uploadUser();
  }

  @Test
  public void testView() {
    init();
    NUPlannerView view = new NUPlannerTextView(planner);
    assertEquals("User: Claire Stewart\n"
            + "Sunday: \n"
            + "Monday: \n"
            + "Tuesday: \n"
            + "Wednesday: \n"
            + "Thursday: \n"
            + "Friday: \n"
            + "Saturday: \n"
            + "User: Cali Behling\n"
            + "Sunday: \n"
            + "Monday: \n"
            + "Tuesday: \n"
            + "Wednesday: \n"
            + "Thursday: \n"
            + "Friday: \n"
            + "Saturday: \n", view.toString());
    planner.createEvent("OOD", new ArrayList<>(),
            new Location(true, "Churchill 101"),
            new Time(Day.TUESDAY, Day.TUESDAY, "0950", "1130"), cali);
    planner.createEvent("Lunch", new ArrayList<>(Arrays.asList(cali)),
            new Location(false, "Tatte"),
            new Time(Day.MONDAY, Day.MONDAY, "1200", "1300"), claire);
    assertEquals("User: Claire Stewart\n"
            + "Sunday: \n"
            + "Monday: \n"
            + "\tname: Lunch\n"
            + "\ttime: Monday: 1200 -> Monday: 1300\n"
            + "\tlocation: Tatte\n"
            + "\tonline: false\n"
            + "\tinvitees: Claire Stewart\tCali Behling\t\n"
            + "Tuesday: \n"
            + "Wednesday: \n"
            + "Thursday: \n"
            + "Friday: \n"
            + "Saturday: \n"
            + "User: Cali Behling\n"
            + "Sunday: \n"
            + "Monday: \n"
            + "\tname: Lunch\n"
            + "\ttime: Monday: 1200 -> Monday: 1300\n"
            + "\tlocation: Tatte\n"
            + "\tonline: false\n"
            + "\tinvitees: Claire Stewart\tCali Behling\t\n"
            + "Tuesday: \n"
            + "\tname: OOD\n"
            + "\ttime: Tuesday: 950 -> Tuesday: 1130\n"
            + "\tlocation: Churchill 101\n"
            + "\tonline: true\n"
            + "\tinvitees: Cali Behling\t\n"
            + "Wednesday: \n"
            + "Thursday: \n"
            + "Friday: \n"
            + "Saturday: \n", view.toString());

    NUEvent lunch = new NUEvent("Lunch", new ArrayList<>(Arrays.asList(claire, cali)),
            new Location(false, "Tatte"),
            new Time(Day.MONDAY, Day.MONDAY, "1200", "1300"), claire);
    planner.removeEvent(lunch, claire);
    assertEquals("User: Claire Stewart\n"
            + "Sunday: \n"
            + "Monday: \n"
            + "Tuesday: \n"
            + "Wednesday: \n"
            + "Thursday: \n"
            + "Friday: \n"
            + "Saturday: \n"
            + "User: Cali Behling\n"
            + "Sunday: \n"
            + "Monday: \n"
            + "Tuesday: \n"
            + "\tname: OOD\n"
            + "\ttime: Tuesday: 950 -> Tuesday: 1130\n"
            + "\tlocation: Churchill 101\n"
            + "\tonline: true\n"
            + "\tinvitees: Cali Behling\t\n"
            + "Wednesday: \n"
            + "Thursday: \n"
            + "Friday: \n"
            + "Saturday: \n", view.toString());
  }
}